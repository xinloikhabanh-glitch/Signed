# Touch Studio (iOS)
3 tab: **Tạo key** (quản trị key trên server Vercel), **Cert Studio** (tạo/kiểm tra/ký chứng chỉ X.509, PKCS#12) và **Ký bplist** (tạo chứng chỉ tự động và ký bplist/plist/mobileconfig).
Build: upload `ios-src.zip` (không giải nén) + `.github/workflows/build-ipa.yml` lên repo → Actions → Run workflow → tải TouchStudio-ipa.
IPA chưa ký: cài bằng Sideloadly / AltStore / eSign / TrollStore.
Đổi server: sửa `Config.apiBase` trong Sources/App.swift.
