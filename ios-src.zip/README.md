# Touch Studio (iOS) v1.1
4 tab: **Tạo key** (quản trị key trên server Vercel: mẫu key, QR từng key, tìm theo tên máy, nhật ký, công tắc bảo trì/bắt cập nhật, kiểm tra hệ thống), **Cert Studio**, **Ký bplist** (kho nhiều chứng chỉ có tên + mẫu Wi-Fi/DNS .mobileconfig) và **Cài đặt** (khoá Face ID/Touch ID, xoá mật khẩu admin trong Keychain).
Thanh nhạc mini ở trên cùng, phát file .mp3 nằm trong Resources/.
Build: upload `ios-src.zip` (không giải nén) + `.github/workflows/build-ipa.yml` lên repo → Actions → Run workflow → tải TouchStudio-ipa.
Đổi server: sửa `Config.apiBase` trong Sources/App.swift.
